//Multi-threaded sorting.
#include<stdio.h>
#include<pthread.h>

#define SIZE 8
int array[SIZE] = {8,3,7,4,2,6,5,1};

void *sort_half(void *val)
{
    int *index = (int *)val;
    int start = index[0];
    int end = index[1];

    for(int i=start;i<end;i++)
    {
        for(int j=i+1;j<end;j++)
        {
            if(array[i]>array[j])
            {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
    return NULL;
}

int main()
{
    pthread_t thread1,thread2;
    int ind1[] = {0,SIZE/2};
    int ind2[] = {SIZE/2,SIZE};

    pthread_create(&thread1,NULL,sort_half,ind1);
    pthread_create(&thread2,NULL,sort_half,ind2);
    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);

    printf("Sorted halves ; ");
    for(int i=0;i<SIZE;i++)
    {
        printf("%d ",array[i]);
    }
    printf("\n");
}