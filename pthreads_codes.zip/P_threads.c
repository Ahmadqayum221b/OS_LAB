//a standard thread library. using posix thread lib, we can create 
/*a new conccurent process execution flow.
such that out program can then handle multiple paths.*/

//Thread basics:
//it is simply a function or procedure, that has its own
//existence and runs independently from program's main() procedure/function.
//thread is created using pthread_create(sem_t,attributes,function,val)
//for terminating a thread => pthread_exit()
//for joining the threads to the main process pthread_join()