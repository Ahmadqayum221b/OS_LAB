//Passing Multiple Arguments to a Thread
#include<stdio.h>
#include<pthread.h>
 
typedef struct 
{
    int id;
    char message[50];
} ThreadData;

void *print(void *arg)
{
    ThreadData *data = (ThreadData*)arg;
    printf("Thread id : %d, Message: %s\n",data->id,data->message);
    return NULL;
}

int main()
{
    pthread_t thread;
    ThreadData data = {1,"Hello from the thread"};
    pthread_create(&thread,NULL,print,&data);
    pthread_join(thread,NULL);
}
