#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

//producer-consumer problem using mutex.

#define size 5
pthread_mutex_t lock;
int buffer[size];
int count = 0;

void *producer(void *val)
{
    for(int i=0;i<10;i++)
    {
        pthread_mutex_lock(&lock);
        if(count < size)
        {
            buffer[count++] = i;
            printf("Produced : %d\n",i);
        }
        else 
        {
            printf("Buffer is full\n");
        }
        pthread_mutex_unlock(&lock);
        sleep(1);
    }
    return NULL;
}

void *consumer(void *val)
{
    for(int i=0;i<10;i++)
    {
        pthread_mutex_lock(&lock);
        if(count > 0)
        {
            printf("Consumed : %d\n",buffer[--count]);
        }
        else 
        {
            printf("Buffer is empty.\n");
        }
        pthread_mutex_unlock(&lock);
        sleep(2);
    }
    return NULL;
}

int main()
{
    pthread_t t1,t2;
    pthread_mutex_init(&lock,NULL);
    pthread_create(&t1,NULL,producer,NULL);
    pthread_create(&t2,NULL,consumer,NULL);

    pthread_join(t1,NULL);
    pthread_join(t2,NULL);

    pthread_mutex_destroy(&lock);
}
