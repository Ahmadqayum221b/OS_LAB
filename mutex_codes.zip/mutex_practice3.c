//using Mutex for file writing.
#include<stdio.h>
#include<pthread.h>

pthread_mutex_t file_lock;
FILE *file;

void *writeToFile(void *val)
{
    int value = *(int *)val;
    pthread_mutex_lock(&file_lock);
    fprintf(file,"Thread %d is writing to file\n",value);
    pthread_mutex_unlock(&file_lock);
}

int main()
{
    pthread_t t1,t2;
    int val = 2,val2=3;
    file = fopen("output.txt","w");
    pthread_mutex_init(&file_lock,NULL);
    pthread_create(&t1, NULL, writeToFile, &val);
    pthread_create(&t2, NULL, writeToFile, &val2);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    pthread_mutex_destroy(&file_lock);
    fclose(file);

    printf("File written successfully\n");
}