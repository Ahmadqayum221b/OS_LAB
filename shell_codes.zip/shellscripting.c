/*shell programming is a group of commands grouped together under single file name.
shebang line = #!/bin/bash. =>it is used for starting a script.
variable:
        name="Ahmad"
        age=25
        echo "Name: $name"
        echo "Age: $age"

Reading:
        echo "Enter your name : "
        read name
        echo "Your name is : $name"

Conditional Statements:
                        if,elif,else
        echo "Enter a number"
        read number
        if [ $number -gt 10 ]; then => -gt means greater than
            echo "The number is greater than 10."
        elif [ $number -eq 10 ]; then
            echo "The number is equal to 10"
        else 
            echo "the number is less than 10"
        fi

    le for lesser.
    gt for greater.
    eq for equal
    { => then and } => fi in if conditions.

for loops:
        for item in 1 2 3 4; do
            echo "Item : $item"
            done

while loop:
            count=1
            while [ $count -le 5 ]; do
                echo "Count: $count"
                ((count++))
            done

echo "Function"
sum() {
    num1=5
    num2=10
    echo "Sum : $((num1 + num2))"
}
sum

Command line Argument:
echo "Script name : $0"
echo "First arg : $1"
echo "Second arg : $2"

file Operations:

        file = "example.txt"
        if [ -f "$file" ]; then
            echo "$file exists"
        else 
            echo "$file doesnot exists"
        fi
-f for file. it is basically the file that it exists or not.

Read a file line by line:

    while IFS= [ read -r line ];
    do
        echo "$line"
    done < "example.txt"

Redirection:

echo "This will go into a file " > example.txt
it is basically redirecting an output to a file.

echo "This will be appended" >> example.txt
this text will be appended in the file.

Backup files.

    source_dir="/path/to/source"
    backup_dir="/path/to/backup"

    echo "Starting backup..."
    cp -r "$source_dir" "$backup_dir"
    echo "Backup COmpleted"

*/
