#!/bin/bash

#printing numbers from 1 to 10 
for i in {1..10}; do
    echo "$i"
done

#check if number is even or odd.
for i in {1..10}; do
    if ((i % 2 == 0)); then
        echo "Even"
    else 
        echo "Odd"
    fi
done