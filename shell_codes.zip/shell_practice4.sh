#!/bin/bash

#displaying the size of a directory.

read -p "Enter a directory path : " dir
if [ -d "$dir" ]; then
    echo "$dir is a valid directory"
    du -sh "$dir"
else 
    echo "$dir is not a valid directory"
fi 