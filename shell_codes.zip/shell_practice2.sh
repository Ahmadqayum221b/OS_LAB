#!/bin/bash

#here we check if a file exists or not.

file="example.txt"
if [ -e "$file" ]; then
    echo "File $file exists"
else 
    echo "File $file doesnot exist"
fi