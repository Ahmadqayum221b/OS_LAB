#!/bin/bash

#simple calculator.

echo "Enter 2 numbers : "
read a
read b
echo "Choose operation : + - * /"
read op

case $op in 
    +) echo "Result : $(($a + $b))" ;;
    -) echo "Result : $(($a - $b))" ;;
    \*) echo "Result : $(($a * $b))" ;;
    /) echo "Result : $(($a / $b))" ;;
    *) echo "Invalid operation" ;;
esac