#!/bin/bash
name="Ahmad"
Age=25
echo "Name : $name"
echo "Age : $Age"

echo "Enter your opponent's name : "
read o_name
echo "Opponent's name : $o_name"

echo "If-condition."

echo "Enter a number"
        read number
        if [ $number -gt 10 ]; then
            echo "The number is greater than 10."
        elif [ $number -eq 10 ]; then
            echo "The number is equal to 10"
        elif [ $number -le 10 ]; then
            echo "The number is less than 10"
        fi

echo "For loop"

for item in 1 2 3 4; do
    echo "Item : $item"
done

echo "While loop"
count=1
while [ $count -le 5 ]; do
    echo "Count: $count"
    ((count++))    
done

echo "Function"
sum() {
    num1=5
    num2=10
    echo "Sum : $((num1 + num2 + num2))"
}

sum

echo "Command line arg"

echo "Script name : $0"
echo "First arg : $1"
echo "Second arg : $2"

echo "File Operations"
file="example.txt"
if [ -f "$file" ]; then
    echo "$file exists"
else 
    echo "$file doesnot exists"
fi

echo "Read a file line by line:"

    while IFS= read -r line; do
        echo "$line"
    done < "example.txt"

echo "This line will be added to the file" > example.txt
echo "this line will be appended" >> example.txt

echo "Backup files"

source_dir="/path/to/source"
backup_dir="/path/to/backup"

echo "Starting backup..."
cp -r "$source_dir" "$backup_dir"
echo "Backup Completed"