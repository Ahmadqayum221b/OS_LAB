#!/bin/bash

#find and replace text in a file.

read -p "Enter filename : " file
read -p "Enter the text to replace : " old
read -p "Enter the new text : " new
if [ -e "$file" ]; then
    sed -i "s/$old/$new/g" "$file"
    echo "Replaced all occurrences of '$old' with '$new'."
else 
    echo "File $file doesnot exist."
fi