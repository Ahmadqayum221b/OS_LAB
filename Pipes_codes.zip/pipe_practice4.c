#include<unistd.h>
#include<sys/types.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//using pipe to communicate between parent and child with dynamic data.
int main()
{
    int pfd[2];
    pipe(pfd);

    pid_t pid = fork();
    if(pid == 0)
    {
        close(pfd[1]); //close write end.
        char buffer[100];
        read(pfd[0],buffer,sizeof(buffer)); //read from pipe.
        printf("Child received : %s\n",buffer);
        close(pfd[0]);
    }
    else 
    {
        close(pfd[0]); //close read end.

        //Dynamically create a message.
        char message[100];
        snprintf(message,sizeof(message),"Dynamic message with pid: %d",getpid());

        write(pfd[1],message,strlen(message)); //write to pipe.
        close(pfd[1]);
    }
}

/*
    In this code, what is basically happening is that
    inter-process communication using pipe.
    parent process creates a pipe and then forks a child process.
    the child process closes the write end of the pipe, reads the
    message from the read end, and prints it. The parent process 
    creates a dynamic message containing its process ID, writes it to
    the pipe, and then closes the write end.

    The message is passed from parent to child through pipe, and the child receives and prints it.
*/