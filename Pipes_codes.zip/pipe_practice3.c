#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/types.h>

int main()
{
    int pfd[2];
    char message[] = "Hello from everyone!";
    char buffer[100];

    if(pipe(pfd) == -1)
    {
        perror("Pipe creation failed\n");
        return -1;
    }

    for(int i=0;i<3;i++)
    {
        pid_t pid = fork();
        if(pid == 0)
        {
            close(pfd[1]);
            read(pfd[0],buffer,sizeof(buffer));
            printf("Child %d received: %s\n",i+1,buffer);
            close(pfd[0]);
            return 0;
        }
    }

    //parent process.
    close(pfd[0]);
    write(pfd[1],message,strlen(message));
    close(pfd[1]);
    return 0;
}


/*
    In this code, what is basically happening is that
    a pipe is created to facilitate communication between parent and
    child processes. The parent proess creates a pipe and then forks three
    child processes in loop.

    Each child processes closes the write end of the pipe,
    reads the message from the pipe and prints it with child number.

    Parent process writes a message ("Hello from everyone!") into the pipe
    and then closes the write end. 

    However, b/c the parent writes the message only once and all the child
    processes are forked before the message is written, only the first child 
    process that executes will successfully read the message from the pipe.

    The other child processes will not be able to read the message as the pipe
    is empty after the first read.

    Summary, parent process closes the write end after writing and child processes
    closes the read end after reading.
*/