#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
    int pfd[2];
    pipe(pfd);
    if(fork() == 0)
    {
        close(pfd[1]);
        dup2(pfd[0],0);
        close(pfd[0]);
        execlp("wc","wc",(char *)0);
    }
    else 
    {
        close(pfd[0]);
        dup2(pfd[1],1);
        close(pfd[1]);
        execlp("ls","ls",(char *)0);
    }
}

/*
    in this code, what is basically happening is that
    how to use pipes and fork to create a pipeline between
    2 processes.
    The pipe(pfd) => creates a pipe with 2 file descriptors.
        1)- for reading. pfd[0]
        2)- for writing. pfd[1]
    Then it uses a fork() to create child process.
    in the child process, the program closes the write end of the pipe,
    redirects the read end(pfd[0]) to standard input using dup2 and then executes the
    wc command (word count). 

    In the parent process, the program closes the read end of the pipe and 
    redirects the write end(pfd[1]) using dup2, and executes the ls command.

    This way the child parent process can do the correct implementation of 
    pipes
    in which one process can only lead from the other, when it getting written.

    dup2 => it is a system call that basically duplicates one file descriptor
    to another.

    int dup2(int oldfd,int newfd);
    in this,
    oldfd => the file descriptor that you want to duplicate.
    newfd => the file descriptor that you want to oldfd to be copied to.
*/