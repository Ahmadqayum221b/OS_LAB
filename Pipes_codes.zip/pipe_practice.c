#include<unistd.h>
    int main()
    {
        int pid;
        int pfd[2];
        char aString[20];
        pipe(pfd);
        pid = fork();
        if(pid == 0)
        {
            write(pfd[1],"Hello",5); // write in pipe.
        }
        else 
        {
            read(pfd[0],aString,5); // read from pipe.
        }
    }

/*
    what the above code is doing that, it is creating
    a pipe using a pipe system call.
    why pfd[2], because pfd 0 for input and so on.
*/

