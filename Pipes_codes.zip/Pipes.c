/*
    In this we will be learning what are pips.
    pipes are IPC technique for processes to communicate
    with one another.

    It can also be used by 2 threads in a same process to communicate with 
    each other.

    Pipes are composed of 3 file descriptors.
    1)- input. => fd = 0.
    2)- output. => fd = 1.
    3)- error. => fd = 2.

    for printf, use fd = 1, standard output.
    for scanf, use fd = 0, standard input.

    So basically what pipes does is,
        => it redirects the standard output of one process
           to become the standard input of another.

    pipes will be a buffer region in the main memory which will be 
    accessible by only 2 processes.
        => one process reads from the buffer while the other one write to it.
        => one process canoot read from the buffer until the other has written to it.

    Pipe On The Shell:
        pstree.
            => in output, it gives us a very huge kind of a tree or output.
        for making it short.
        ptree | less
            with this using up and down arrows you can browse through the 
            output.
            To exit, press q.
            | symbol is of pipe.
            pstree and less are 2 processes and pipe is binding them together.
            pstree | grep bash
                => this command will only run those lines of text
            from the pstree output in which the keyword bash appears.

    Pipe System Call:

        #include<unistd.h>
        int main()
        {
            int pfd[2];
            pipe(pfd);
        }

        in Pipes, what happens is, in child when output is being
        placed the input block is closed
        and if the input is being placed the output block is closed.

*/