#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<signal.h>
#include<sys/types.h>

void handle_siguser(int num)
{
    printf("Received SIGUSR1 (signal %d). Custom user signal.\n",num);
}

int main()
{
    pid_t pid = getpid(); // this will give us current process id.
    signal(SIGUSR1,handle_siguser);
    printf("Process ID : %d\n",pid);
    printf("Send SIGUSR1 using 'kill -SIGUSR1 %d'\n",pid);
    
    while(1)
    {
        printf("Waiting for signal...\n");
        sleep(2);
    }
    return 0;
}

/*
    in this code, what is happening is that
    the program first get its own process ID using getpid().
    it then sets up a custom signal handler,
    which gets executed whenever the SIGUSR1 signal is sent to the 
    process.
    This is a way to respond to custom signals in a program.
    SIGUSR1 is a flexible, user-reserved signal for developers to define custom
    functionality in their applications.
*/