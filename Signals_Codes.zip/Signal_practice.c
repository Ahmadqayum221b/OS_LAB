#include<unistd.h>
#include<signal.h>
#include<stdio.h>
#include<stdlib.h>
int count = 0;
void sigHandler(int num)
{
    printf("Signal received is %d\n",num);
    ++count;
    printf("Signal received is %d\n",count);
    if(count >= 5)
    {
        exit(0);
    }
}

int main()
{
    signal(SIGINT,sigHandler);
    while(1)
    {
        printf("Hello Everyone\n"); 
        sleep(1);                   
    }
    return 0;
}


/*
    Here in this code, what is basically happening is that
    this code, registers a signal handler to handle SIGINT signals
    which is triggered by pressing Ctrl+C.
    By pressing Ctrl+C, this increments a count and prints the signal 
    number and count each time the signal is received. 
*/
