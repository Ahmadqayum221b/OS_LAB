#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>

//Ctrl+C is handling this.
void handle_sigint(int num) 
{
    printf("\nReceived SIGINT (signal %d). You pressed Ctrl+C!\n",num);
}

//Ctrl+Z is handling this.
void handle_sigtstp(int num) 
{
    printf("\nReceived SIGTSTP (signal %d). You pressed Ctrl+Z!\n",num);
}

int main()
{
    signal(SIGINT,handle_sigint);
    signal(SIGTSTP,handle_sigtstp);

    printf("Ctrl+C for SIGINT or Ctrl+Z for SIGSTP\n");
    while(1)
    {
        printf("Waiting for signal...\n");
        sleep(2);
    }
    return 0;
}

/*
    in this code, what is basically happening is that
    we are handling 2 signals SIGINT and SIGTSTP in c.
    when we press Ctrl+C, the program catches SIGINT signal
    and executes the handle_sigint() function, and similarly when 
    we presses Ctrl+Z, the program catches SIGTSTP and executes the handle
    _sigtstp() function.
*/