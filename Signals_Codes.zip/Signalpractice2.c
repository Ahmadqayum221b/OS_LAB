// Graceful exit on SIGTERM.
#include<signal.h>
#include<stdlib.h>
#include<unistd.h>
#include<stdio.h>

void handle_sigterm(int num)
{
    printf("\nReceived SIGTERM (signal %d). Exiting Gracefully...\n",num);
    exit(0); // exit the program.
}

int main()
{
    signal(SIGTERM,handle_sigterm);

    printf("Running program.Send SIGTERM to terminate ('kill -SIGTERM %d')\n",getpid());
    while(1)
    {
        printf("Program running... Press Ctrl+C to test other signals.\n");
        sleep(2);
    }
    return 0;
}


/*
    in this code, what is basically happening is that
    SIGTERM signal is used which we will be using for gracefully
    terminating a running process.
    It basically terminates a program, working as a kill -SIGTERM PID.
    Clean shutdown basically when the process receive termination requests.
*/