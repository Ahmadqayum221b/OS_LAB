//They are an interprocess communication mechanism.
/*
    It is provided by OS which facilitate communication
    between processes.
    Usually used for notifying a certain process about a certain
    event that has occurred.

    So basically, signals are an event-notification system provided by OS.
*/

/*
    Signal Delivery Using Kill:

        Kill is a delivery mechanism in which a signal gets sent to a process.
    it isued only to send a signal to a process.
    I mean it can also kill a process as well, but it is not necessarily made for that.

    Syntax of Kill Command:

        kill -s PID
    1)- kill is the command itself.
    2)- -s is an argument which specifies the type of signal to send.
        Examples:
            kill -s SIGHUP PID => hangup, it is often used to reload configuration.
            kill -s SIGKILL PID => it forcefully terminates a process.
            kill -s SIGTERM PID => it terminates the process, when the process gets done.
    3)- PID is the process ID of the target process.

    Signal Numbers:
    
    Instead of names, you can also use signal numbers. For example, the equivalent 
    number of SIGKILL is signal number 9.
    => kill -9 PID.

    And to see a list of all available signals, what you can do is;
    => kill l


    In signals, if you want to echo your message from one terminal to the other terminal.
    what you do is,

    echo "Ahmad" > /proc/PID_Value_of_Terminal_that_You_want_to_send/fd/1
    this will send Ahmad to that terminal.

*/