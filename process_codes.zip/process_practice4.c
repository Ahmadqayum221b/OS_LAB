#include<unistd.h>
#include<stdio.h>

int main()
{
    int p;
    char *arg[] = {"/usr/bin/ls",0};
    p = fork();
    if(p == 0)
    {
        printf("Child process\n");
        execv(arg[0],arg);
        printf("child process\n");
    }
    else 
    {
        printf("Parent Process\n");
    }
}

/*
    In this code, what is basically happening is that
    the child process is replaced bu the ls command ,so it doesnt print "child process"
    after calling execv().

    The parent process just prints "Parent process" and doesnt execute any other sig code.
*/