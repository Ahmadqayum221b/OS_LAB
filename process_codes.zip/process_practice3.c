#include<sys/types.h>
#include<unistd.h>
#include<stdio.h>

int main()
{
    printf("Parent process (PID %d)\n",getpid());
    if(fork() == 0)
    {
        printf("Child process 1 (PID : %d, parent PID: %d)\n",getpid(),getppid());
    }
    else 
    {
        if(fork() == 0)
        {
            printf("Child process 2 (PID %d, Parent PID: %d)\n",getpid(),getppid());
        }
        else 
        {
            if(fork() == 0)
            {
                printf("Child process 3 (PID : %d, parent PID: %d)\n",getpid(),getppid());
            }
            else 
            {
                if(fork() == 0)
                {
                    printf("Child process 4 (PID : %d, parent PID: %d)\n",getpid(),getppid());
                }
                else 
                {
                    if(fork() == 0)
                    {
                        printf("Child process 5 (PID : %d, parent PID: %d)\n",getpid(),getppid());
                    }
                }
            }
        }
    }
    sleep(10);
}

/*
    Here in this code, what we are basically doing is that
    we are making 6 processes including the parent process.
*/  