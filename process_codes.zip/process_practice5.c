#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
//atexit and exit system calls.
int main()
{
    void f1(),f2(),f3();
    atexit(f1);
    atexit(f2);
    atexit(f3);
    printf("Getting ready to exit.\n");
    exit(0);
}

void f1()
{
    printf("In f1\n");
}

void f2()
{
    printf("In f2\n");
}

void f3()
{
    printf("In f3\n");
}

//exit:
//exit system call is used to terminate a program immediately.
//what exit(), does is that it stops a program immediately and performs cleanup tasks like flushing output buffers
//it is mostly used when you want to end the program.


/*
    atexit:
        atexit() system call is used to register one or more functions
        that should be called when the program terminates.
    In this the last registered is called first. in the above code,
    the f3 function will be printed out first.

    in summary:
        1)-exit() is used to terminate the program at a specific point.
        2)-atexit() to register cleanup functions that will automatically run when the program 
        exits.
*/