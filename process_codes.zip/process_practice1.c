#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main()
{
    int i;
    printf("Process PID %6d \t %6d \n",getpid(),getppid());
    for(int i=0;i<1;i++)
    {
        if(fork() == 0)
        {
            printf("Process PID %6d \t %6d \n",getpid(),getppid());
        }
    }
    return 0;
}

//getpid() id of the current process.
//getppid() id of the parent process. 