/*
    process is the fundamental block of each program.
    process is when a program is executed.

    For checking a list of processes in the system for a user.
    you enter
            ps command.
    to view the complete list,

            ps au

    You will see plenty of columns as output. The columns you should
    be familiar with at this moment are below:

    You will see the following things;
    1)- User => owner of the process.
    2)- PID => integer identifier.
    3)- CPU => % utilization of CPU.
    4)- MEM => % utilization of Memory space.
    VSZ => Virtual memory size.
    RSS => Non-swapped physical memory size.
    TTY => Controlling Terminal.

    The basic attributes of a process is its ID(PID), and its
    Parent ID(PPID). The system calls that can find the process ID, 
    and the Parent Process ID are getpid() and getppid() calls.
    To use these system calls,
    we use the following libraries,
        #include<sys/types.h>
        #include<unistd.h>
    
    pstree command is used to view the hierarchy of parent,child and grand child processes.

    Process Lifecycle:

        each process has to go through the following states during it's exercise.
        1)- Creation.
        2)- Running.
        3)- Non-Running.
            a)-Ready.
            b)-Waiting.
        4)- Termination.
*/