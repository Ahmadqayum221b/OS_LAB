//Death of Parent or Child.

//Parent Dies Before Child
/*
    if a parent process dies before a child process, the child
    gets orphaned. They will be assigned to another process in the system
    and as such the children should be informed about who their new parent
    is going to be.
    This new parent process is basically parent of all processes called init process.

*/

#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
// int main()
// {
//     int i,pid;
//     pid = fork();
//     if(pid > 0)
//     {
//         sleep(2);
//         exit(0);
//     }
//     else if(pid == 0)
//     {
//         for(int i=0;i<5;i++)
//         {
//             printf("My parent is %d\n",getppid());
//             sleep(1);
//         }
//     }
// }

/*
    Child Dies Before Parent.
    When a child process dies before parent process,
    it becomes a zombie process.
    When a child process terminates, it sends a SIGCHLD signal 
    to its parent to notify it of its exit status.

    The terminated child process enters the 'zombie' state until the parent
    explicitly collects its termination status by calling wait() or waitpid().

    In the zombie state:
        the child proces remains in the process table, but it doesnot consume any system 
        resources like memory or CPU.
*/

int main()
{
    int i,pid;
    pid = fork();
    if(pid > 0)
    {
        sleep(12);
    }
    else if(pid == 0)
    {
        exit(0);
    }
}