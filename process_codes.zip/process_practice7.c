//Process Communication using Pipes.

#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include <sys/types.h>

int main()
{
    int pfd[2];
    pipe(pfd);

    pid_t pid = fork();

    if(pid == 0)
    {
        close(pfd[1]); // closing the write end.
        char buffer[100];
        read(pfd[0],buffer,sizeof(buffer));
        printf("Child received : %s\n",buffer);
        close(pfd[0]);
    }
    else 
    {
        close(pfd[0]); //close read end.
        char message[] = "Hello from everyone";
        write(pfd[1],message,strlen(message) + 1);
        close(pfd[1]);
    }
}