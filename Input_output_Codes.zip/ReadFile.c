/*
    In this we use read() system call.

    Syntax:
            read(fd,buffer,size);

    this system call would require unistd.h library.
    Parameters are;
    1)- file descriptor.
    2)- buffer or place where data is to be stored.
    3)- length to read.
*/