/*
    In this we will be writing to a file using write call.
    syntax:

        write(fd,buffer,size);
        1)- file descriptor.
        2)- buffer where data is stored.
        3)- size of the buffer.
*/