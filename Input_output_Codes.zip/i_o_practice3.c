#include<fcntl.h>
#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>

int main(int argc,char *argv[])
{
    char *path = argv[1];
    int fd = open(path,O_RDONLY|O_CREAT);
    if(fd == -1)
    {
        printf("File doesnot exist.\n");
        return -1;
    }
    char buffer[200];
    read(fd,buffer,sizeof(buffer)-1);
    printf("Contents of File are : \n");
    printf("%s\n",buffer);
    close(fd);
    return 0;
}

/*
    In this code what is basically happening is that
    we are reading the content of a file specified as a 
    command-line argument and displays them on the console.
    It takes the file path from the first argument (argv[1])
    and tries to open the file in read-only mode using open()
    if a file exists, it reads its contents into a buffer using read()
    prints the contents and then closes the file using close().
*/