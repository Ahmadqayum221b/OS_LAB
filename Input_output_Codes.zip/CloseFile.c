/*
    Close File:

    close(int value)
    It is used to close a file.
    When a process terminates, linux by default
    closes all file descriptors so you may not close a file by yourself
    if you don't want to.

    So it's a good idea, that if the file descriptors are not used it should be close.
    Cause there are 1,024 file descriptors per process by default.
*/