#include<fcntl.h>
#include<sys/types.h>
#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
//Open File
int main(int argc,char *argv[])
{
    char *path = argv[1];
    int fd = open(path,O_WRONLY|O_CREAT|O_RDONLY|O_EXCL);
    if(fd == -1)
    {
        printf("Error: File not created");
        return -1;
    }
    return 0;
}

/*
    Here in this code what we are basically doing is that
    we are creating a new file.
    and then in the terminal if that file already exists it will say
    Error: File not created.
*/