#include<fcntl.h>
#include<sys/types.h>
#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
//Close a file.

int main(int argc,char *argv[])
{
    char *path[] = {"File4","File5"};
    int i=0;
    while(i<2)
    {
        int fd = open(path[i],O_WRONLY|O_CREAT);
        printf("Created! Descriptor is %d\n",fd);
        close(fd);
        i++;
    }
}

// Here the only thing we are doing is after creating a file we are simply closing it.