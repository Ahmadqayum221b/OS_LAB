/*
    In linux, there are three types of files that are
    open all the time for input and output purposes for each
    process.
    1)- Standard input stream.
    2)- Standard output stream.
    3)- Standard Error stream.

    Each stream is represented by a file descriptor.
    input = 0.
    output = 1.
    error = 2.

    Echo Command:

        echo prints what you have written in the terminal.
        echo "Ahmad" will print Ahmad on the terminal.

    To write a string Hello to a file hello.txt using echo.
    what we can do is,
    echo "Hello" > hello.txt

    Now for transferring a message from one terminal to another
    what we do is use /proc/PID_value/fd/1
    Pid_value => value of terminal.
    so,
        echo "Hello" > /proc/26412/fd/1
*/