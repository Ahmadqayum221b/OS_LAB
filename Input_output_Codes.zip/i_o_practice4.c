#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<time.h>
#include<unistd.h>

char *get_timeStamp()
{
    time_t presentTime = time(NULL);
    return asctime(localtime(&presentTime));
}

int main(int argc,char *argv[])
{
    char *filename = argv[1];
    char *timestamp = get_timeStamp();
    int fd = open(filename,O_WRONLY|O_RDONLY|O_CREAT|O_APPEND,0666);
    size_t length = strlen(timestamp);
    write(fd,timestamp,length);
    close(fd);
    return 0;
}

/*
    in this code, what is basically happening is that
    we are writing the current timestamp to a file specified.
    as a command line argument.
    we are using a get_timestamp() function to get the current time formatted as
    a string.

    The program opens or if not created creates it first the file in read-write mode
    with append permissions using open().
    the timestamp is written in the file and after that it is closed.
    each time you run the program, a new time stamp is appended to the file.
*/