/*
    Open a file:

        open() call to open a file.
    it can also be used for creating a file.

    syntax as,
              int open(pathname,int flag,int mode/modes);
    libraries for it will be,

    #include<sys/types.h>
    #include<fcntl.h>
    #include<sys/stat.h>

    Paramters are;
        1)- Pathname of the file to open.
        2)- Flag specifying like how to open it
            i mean for reading purpose, writing purpose etc.
        3)- Access permissions for file.

    Flags:
    
        Some of the flags are listed below:

        1)- O_RDONLY => for marking a file as readonly.
        2)- O_WRONGLY => for marking a file as write only.
        3)- O_RDWR => for marking a file a s read and write.
        4)- O_CREAT => for creating a new file.
        5)- O_EXCL => for giving an error when creating a file and it already exists.
*/