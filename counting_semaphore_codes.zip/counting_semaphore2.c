#include<pthread.h>
#include<semaphore.h>
#include<stdio.h>
#include<unistd.h>

//controlling access to a limited resource.

#define count 3
sem_t resourceSem;

void *threadFun(void *val)
{
    int value = *(int *)val;
    printf("Thread %d is waiting for resource...\n",value);
    sem_wait(&resourceSem);
    printf("Thread %d acquired a resource.\n",value);
    sleep(2);

    printf("Thread %d release a resource.\n",value);
    sem_post(&resourceSem);

}   

int main()
{
    pthread_t threads[5];
    int thread_ids[5];
    sem_init(&resourceSem,0,count);

    for(int i=0;i<5;i++)
    {
        thread_ids[i] = i+1;
        pthread_create(&threads[i],NULL,threadFun,&thread_ids[i]);
    }

    
    for(int i=0;i<5;i++) 
    {
        pthread_join(threads[i],NULL);
    }

    sem_destroy(&resourceSem);
}