//producer-consumer with counting semaphore.

#include<pthread.h>
#include<semaphore.h>
#include<stdio.h>
#include<stdlib.h>

#define size 5

int buffer[size];
int in=0;
int out=0;

sem_t empty;
sem_t full;
pthread_mutex_t mutex;

void *producer(void *val)
{
    int value = *(int *)val;
    for(int i=0;i<10;i++)
    {
        int item = rand() % 100;
        sem_wait(&empty);
        pthread_mutex_lock(&mutex);

        buffer[in] = item;
        printf("Produced %d\n",item);
        in = (in + 1) % size;
        pthread_mutex_unlock(&mutex);
        sem_post(&full);
    }
}

void *consumer(void *val)
{
    int value = *(int *)val;
    for(int i=0;i<10;i++)
    {
        sem_wait(&full);
        pthread_mutex_lock(&mutex);
        int item = buffer[out];
        printf("Consumed %d\n",item);
        out = (out + 1) % size;
        pthread_mutex_unlock(&mutex);
        sem_post(&empty);
    }
}

int main()
{
    pthread_t prod,cons;

    sem_init(&empty,0,size);
    sem_init(&full,0,0);

    pthread_mutex_init(&mutex,NULL);
    pthread_create(&prod,NULL,producer,NULL);
    pthread_create(&cons,NULL,consumer,NULL);
    pthread_join(prod,NULL);
    pthread_join(cons,NULL);

    sem_destroy(&empty);
    sem_destroy(&full);
    pthread_mutex_destroy(&mutex);
}
