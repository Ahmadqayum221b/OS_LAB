#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<sys/time.h>
#include<unistd.h>
#include<stdlib.h>
sem_t semaphore;

void *thread1_function(void *val)
{
    printf("Thread 1 waiting...\n");
    sem_wait(&semaphore);
    printf("Thread 1 executing");
    sem_post(&semaphore);
}

void *thread2_function(void *val)
{
    printf("Thread 2 doing work.\n");
    sleep(1);
    printf("Thread 2 posting semaphore.\n");
    sem_post(&semaphore);
}

int main()
{
    pthread_t thread1,thread2;
    pthread_create(&thread1,NULL,thread1_function,NULL);
    pthread_create(&thread2,NULL,thread2_function,NULL);

    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);

    sem_destroy(&semaphore);
}