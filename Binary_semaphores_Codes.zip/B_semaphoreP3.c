#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>

sem_t empty,full;
int buffer = 0;

void *producer(void *val)
{
    for(int i=0;i<5;i++)
    {
        sem_wait(&empty);
        buffer += i;
        printf("Item produced : %d\n",buffer);
        sem_post(&full);
        sleep(2);
    }
}

void *consumer(void *val)
{
    for(int i=0;i<5;i++)
    {
        sem_wait(&full);
        printf("Consume item : %d\n",buffer);
        buffer -= i;
        sem_post(&empty);
        sleep(3);
    }
}

int main()
{
    pthread_t _producer,_consumer;
    sem_init(&empty,0,1);
    sem_init(&full,0,0);
    pthread_create(&_producer,NULL,producer,NULL);
    pthread_create(&_consumer,NULL,consumer,NULL);

    pthread_join(_producer,NULL);
    pthread_join(_consumer,NULL);

    sem_destroy(&empty);
    sem_destroy(&full);

}