#include<stdio.h>
#include<unistd.h>
#include<semaphore.h>
#include<sys/time.h>
#include<pthread.h>

sem_t semaphore;

void *thread_function(void *val)
{
    int value = *(int *)val;
    sem_wait(&semaphore);
    printf("Thread %d is entering the critical section.\n",value);
    sleep(1);
    printf("Thread %d is leaving the critical section.\n",value);
    sem_post(&semaphore);
    return NULL;
}

int main()
{
    pthread_t threads[3];
    sem_init(&semaphore,0,1);
    for(int i=0;i<3;i++)
    {
        pthread_create(&threads[i],NULL,thread_function,&i);
    }
    for(int i=0;i<3;i++)
    {
        pthread_join(threads[i],NULL);
    }
    sem_destroy(&semaphore);
}